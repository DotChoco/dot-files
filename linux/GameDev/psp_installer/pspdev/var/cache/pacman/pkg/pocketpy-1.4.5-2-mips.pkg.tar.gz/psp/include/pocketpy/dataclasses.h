#pragma once

#include "cffi.h"

namespace pkpy{

void add_module_dataclasses(VM* vm);

} // namespace pkpy