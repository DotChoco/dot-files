#pragma once

#include "cffi.h"

namespace pkpy {

void add_module_csv(VM* vm);

} // namespace pkpy