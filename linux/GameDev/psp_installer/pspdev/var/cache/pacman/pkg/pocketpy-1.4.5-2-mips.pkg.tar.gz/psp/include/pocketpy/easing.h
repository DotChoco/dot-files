#pragma once

#include "cffi.h"

namespace pkpy{

void add_module_easing(VM* vm);

} // namespace pkpy