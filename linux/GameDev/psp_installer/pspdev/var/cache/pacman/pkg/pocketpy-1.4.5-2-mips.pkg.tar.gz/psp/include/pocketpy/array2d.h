#pragma once

#include "bindings.h"

namespace pkpy {

void add_module_array2d(VM* vm);

} // namespace pkpy