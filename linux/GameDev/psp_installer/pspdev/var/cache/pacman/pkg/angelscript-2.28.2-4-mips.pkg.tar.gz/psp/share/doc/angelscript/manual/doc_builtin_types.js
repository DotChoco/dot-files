var doc_builtin_types =
[
    [ "Primitives", "doc_datatypes_primitives.html", [
      [ "void", "doc_datatypes_primitives.html#void", null ],
      [ "bool", "doc_datatypes_primitives.html#bool", null ],
      [ "Integer numbers", "doc_datatypes_primitives.html#int", null ],
      [ "Real numbers", "doc_datatypes_primitives.html#real", null ]
    ] ],
    [ "Objects and handles", "doc_datatypes_obj.html", [
      [ "Objects", "doc_datatypes_obj.html#objects", null ],
      [ "Object handles", "doc_datatypes_obj.html#handles", null ]
    ] ],
    [ "Function handles", "doc_datatypes_funcptr.html", null ]
];