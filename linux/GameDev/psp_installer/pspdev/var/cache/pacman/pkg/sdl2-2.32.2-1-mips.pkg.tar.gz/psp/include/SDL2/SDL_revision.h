/* #undef SDL_VENDOR_INFO */
#define SDL_REVISION_NUMBER 0

#ifdef SDL_VENDOR_INFO
#define SDL_REVISION "SDL-release-2.32.2-0-ge11183ea6 (" SDL_VENDOR_INFO ")"
#else
#define SDL_REVISION "SDL-release-2.32.2-0-ge11183ea6"
#endif
