#ifndef _AL_STATE_H_
#define _AL_STATE_H_

#include "AL/al.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif
