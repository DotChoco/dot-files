var doc_script_global =
[
    [ "Functions", "doc_script_func.html", "doc_script_func" ],
    [ "Variables", "doc_global_variable.html", null ],
    [ "Virtual properties", "doc_global_virtprop.html", null ],
    [ "Script classes", "doc_script_class.html", "doc_script_class" ],
    [ "Interfaces", "doc_global_interface.html", null ],
    [ "Mixin class", "doc_script_mixin.html", null ],
    [ "Enums", "doc_global_enums.html", null ],
    [ "Funcdefs", "doc_global_funcdef.html", null ],
    [ "Typedefs", "doc_global_typedef.html", null ],
    [ "Namespaces", "doc_global_namespace.html", null ],
    [ "Imports", "doc_global_import.html", null ]
];