#pragma once

#include "cffi.h"

namespace pkpy {

void add_module_base64(VM* vm);

} // namespace pkpy