#pragma once

#include "cffi.h"

namespace pkpy{

void add_module_random(VM* vm);

} // namespace pkpy