var structas_s_v_m_registers =
[
    [ "ctx", "structas_s_v_m_registers.html#aaaf2063a2786459281f9426f5083f8d1", null ],
    [ "doProcessSuspend", "structas_s_v_m_registers.html#ae1fe3cb6cbcf870cfde3364e66909e4f", null ],
    [ "objectRegister", "structas_s_v_m_registers.html#a12e6c46db50443d8f7faeec71abf42f7", null ],
    [ "objectType", "structas_s_v_m_registers.html#aa6c240c0861870d7a85aa27fce921b83", null ],
    [ "programPointer", "structas_s_v_m_registers.html#abacce81d44b2387a2b66549bcba47643", null ],
    [ "stackFramePointer", "structas_s_v_m_registers.html#ab1d0ebdb2e9b1b57320ade00beaf229b", null ],
    [ "stackPointer", "structas_s_v_m_registers.html#abb79cddcc4d38d286f221f2b4d323ab6", null ],
    [ "valueRegister", "structas_s_v_m_registers.html#aa87c457f97ce8e49fd808c8b6fd8e9d8", null ]
];